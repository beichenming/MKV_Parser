/****************************************************************************
 ** libmatroska : parse Matroska files, see http://www.matroska.org/
 **
 ** <file/class description>
 **
 ** Copyright (C) 2002-2004 Steve Lhomme.  All rights reserved.
 **
 ** This library is free software; you can redistribute it and/or
 ** modify it under the terms of the GNU Lesser General Public
 ** License as published by the Free Software Foundation; either
 ** version 2.1 of the License, or (at your option) any later version.
 ** 
 ** This library is distributed in the hope that it will be useful,
 ** but WITHOUT ANY WARRANTY; without even the implied warranty of
 ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 ** Lesser General Public License for more details.
 ** 
 ** You should have received a copy of the GNU Lesser General Public
 ** License along with this library; if not, write to the Free Software
 ** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 **
 ** See http://www.gnu.org/licenses/lgpl-2.1.html for LGPL licensing information.**
 ** Contact license@matroska.org if any conditions of this licensing are
 ** not clear to you.
 **
 **********************************************************************/

/*!
 \file
 \version \$Id$
 \brief Test reading of the Header
 \author Steve Lhomme     <robux4 @ users.sf.net>
 */

#include <iostream>
#include <cassert>
#include <math.h>

#if __GNUC__ == 2
#include <wchar.h>
#endif

#include "EbmlHead.h"
#include "EbmlSubHead.h"
#include "EbmlStream.h"
#include "EbmlContexts.h"
#include "EbmlVoid.h"
#include "EbmlCrc32.h"
#include "FileKax.h"
#include "KaxSegment.h"
#include "KaxContexts.h"
#include "KaxTracks.h"
#include "KaxInfoData.h"
#include "KaxCluster.h"
#include "KaxBlockData.h"
#include "KaxSeekHead.h"
#include "KaxCuesData.h"
#include "StdIOCallback.h"

using namespace LIBMATROSKA_NAMESPACE;
using namespace std;
//#define NO_DISPLAY_DATA
//#define JUMP_TEST

/*!
 \note you can generate the file used in this example using test6.cpp
 \todo the blocks with "titi" and "tetetete" don't seem to be read !
 */

int GetSamplingFrequency(int samplingnum) {
    switch (samplingnum) {
        case 96000:
            return 0;
        case 88200:
            return 1;
        case 64000:
            return 2;
        case 48000:
            return 3;
        case 44100:
            return 4;
        case 32000:
            return 5;
        case 24000:
            return 6;
        case 22050:
            return 7;
        case 16000:
            return 8;
        case 12000:
            return 9;
        case 11025:
            return 10;
        case 8000:
            return 11;
        case 7350:
            return 12;
        default:
            return 13;
    }
}

int GetChannels(uint64 channelsnum) {
    switch (channelsnum) {
        case 0:
            return 0;
        case 1:
            return 1;
        case 2:
            return 2;
        case 3:
            return 3;
        case 4:
            return 4;
        case 5:
            return 5;
        case 6:
            return 6;
        case 8:
            return 7;
        default:
            return 0;
    }
}


int main(int argc, char **argv)
{
    try {
        StdIOCallback Cluster_file((argc>=2 ? argv[1] : "/Users/User/Movies/mkv11.mkv"), MODE_READ);
        FILE *video_file = fopen("/Users/User/Desktop/mkv.264", "a");
        FILE *audio_file = fopen("/Users/User/Desktop/mkv.aac", "a");
        if (video_file == NULL || audio_file == NULL) {
            printf("open file fail\n");
            return -1;
        }
        
        bool bAllowDummy = true; // even read elements we don't know (needed for CRC checking)
        
        // read the EBML head
        EbmlStream aStream(Cluster_file);
        EbmlElement * ElementLevel0;
        EbmlElement * ElementLevel1;
        EbmlElement * ElementLevel2;
        EbmlElement * ElementLevel3 = NULL;
        EbmlElement * ElementLevel4 = NULL;
        
        int samplingNum;
        int channelsNum;
        int trackNo;
        int video_h264No = 0;
        int audio_aacNo = 0;
        int audio_ac3No = 0;
        
        // find the EBML head in the file
        ElementLevel0 = aStream.FindNextID(EbmlHead::ClassInfos, 0xFFFFFFFFL);
        if (ElementLevel0 != NULL)
        {
            printf("EBML HEAD %llu : ", ElementLevel0->GetSize());
            for (unsigned int i = 0; i < EbmlId(*ElementLevel0).Length; i++)
            {
                printf("[%02X]", (EbmlId(*ElementLevel0).Value >> (8*(3-i))) & 0xFF);
            }
            printf("\n");
            
            ElementLevel0->SkipData(aStream, EbmlHead_Context);
            if (ElementLevel0 != NULL)
                delete ElementLevel0;
        }
        
        int UpperElementLevel = 0;
        KaxSegment * Segment;
        KaxInfo * SegmentInfo;
        KaxTrackEntry * TrackAudio;
        KaxTrackEntry * TrackVideo;
        KaxCluster *SegmentCluster;
        KaxCues *CuesEntry;
        KaxSeekHead *MetaSeek;
        KaxChapters *Chapters;
        KaxTags *AllTags;
        uint64 TimecodeScale = 1000000;
        
        // find the segment to read
        ElementLevel0 = aStream.FindNextID(KaxSegment::ClassInfos, 0xFFFFFFFFL);
        if (ElementLevel0 != NULL)
        {
            printf("EBML segment %llu : ",ElementLevel0->GetSize());
            for (unsigned int i = 0; i < EbmlId(*ElementLevel0).Length; i++)
            {
                printf("[%02X]", (EbmlId(*ElementLevel0).Value >> (8*(3-i))) & 0xFF);
            }
            printf("\n");
            
            if (EbmlId(*ElementLevel0) == KaxSegment::ClassInfos.GlobalId) {
                Segment = static_cast<KaxSegment*>(ElementLevel0);
                // scan the file for a Tracks element (all previous Level1 elements are discarded)
                ElementLevel1 = aStream.FindNextElement(ElementLevel0->Generic().Context, UpperElementLevel, 0xFFFFFFFFL, bAllowDummy);
                
                while (ElementLevel1 != NULL) {
                    if (UpperElementLevel > 0) {
                        break;
                    }
                    if (UpperElementLevel < 0) {
                        UpperElementLevel = 0;
                    }
                    printf("EbmlId: %x\nLength: %llu\n", EbmlId(*ElementLevel1).Value, ElementLevel1->GetSize());
                    /// \todo switch the type of the element to check if it's one we want to handle, like attachements
                    if (EbmlId(*ElementLevel1) == EbmlVoid::ClassInfos.GlobalId) {
                        printf("\n- Void found: ");
                        for (unsigned int i = 0; i < EbmlId(*ElementLevel1).Length; i++)
                        {
                            printf("[%02X]", (EbmlId(*ElementLevel1).Value));
                        }
                        printf("\n");
                    } else if (EbmlId(*ElementLevel1) == KaxTracks::ClassInfos.GlobalId) {
                        // found the Tracks element
                        printf("\n- Segment Tracks found: ");
                        for (unsigned int i = 0; i < EbmlId(*ElementLevel1).Length; i++)
                        {
                            printf("[%02X]", (EbmlId(*ElementLevel1).Value >> (8*(3-i))) & 0xFF);
                        }
                        printf("\n");
                        // handle the data in Tracks here.
                        // poll for new tracks and handle them
                        ElementLevel2 = aStream.FindNextElement(ElementLevel1->Generic().Context, UpperElementLevel, 0xFFFFFFFFL, bAllowDummy);
                        
                        while (ElementLevel2 != NULL) {
                            if (UpperElementLevel > 0) {
                                break;
                            }
                            if (UpperElementLevel < 0) {
                                UpperElementLevel = 0;
                            }
                            /// \todo switch the type of the element to check if it's one we want to handle, like attachements
                            if (EbmlId(*ElementLevel2) == KaxTrackEntry::ClassInfos.GlobalId) {
                                printf("* Found a track\n");
                                
                                ElementLevel3 = aStream.FindNextElement(ElementLevel2->Generic().Context, UpperElementLevel, 0xFFFFFFFFL, bAllowDummy);
                                while (ElementLevel3 != NULL) {
                                    if (UpperElementLevel > 0) {
                                        break;
                                    }
                                    if (UpperElementLevel < 0) {
                                        UpperElementLevel = 0;
                                    }
                                    uint8 tracktypenow;
                                    // read the data we care about in a track
                                    // Track number
                                    if (EbmlId(*ElementLevel3) == KaxTrackNumber::ClassInfos.GlobalId) {
                                        KaxTrackNumber & TrackNum = *static_cast<KaxTrackNumber*>(ElementLevel3);
                                        TrackNum.ReadData(aStream.I_O());
                                        trackNo = uint8(TrackNum);
                                        printf("Track # %d\n", uint8(TrackNum));
                                    }
                                    // Track type
                                    else if (EbmlId(*ElementLevel3) == KaxTrackType::ClassInfos.GlobalId) {
                                        KaxTrackType & TrackType = *static_cast<KaxTrackType*>(ElementLevel3);
                                        TrackType.ReadData(aStream.I_O());
                                        printf("Track type: ");
                                        tracktypenow = uint8(TrackType);
                                        switch(uint8(TrackType))
                                        {
                                            case track_audio:
                                                printf("Audio");
                                                TrackAudio = static_cast<KaxTrackEntry *>(ElementLevel2);
                                                TrackAudio->SetGlobalTimecodeScale(TimecodeScale);
                                                break;
                                            case track_video:
                                                printf("Video");
                                                TrackVideo = static_cast<KaxTrackEntry *>(ElementLevel2);
                                                TrackVideo->SetGlobalTimecodeScale(TimecodeScale);
                                                break;
                                            default:
                                                printf("unknown");
                                        }
                                        printf("\n");
                                    }
                                    
                                    else if (EbmlId(*ElementLevel3) == KaxTrackFlagLacing::ClassInfos.GlobalId) {
                                        KaxTrackFlagLacing & TrackFlagLacing = *static_cast<KaxTrackFlagLacing*>(ElementLevel3);
                                        TrackFlagLacing.ReadData(aStream.I_O());
                                        printf("Flag Lacing: %d\n", uint8(TrackFlagLacing));
                                    }
                                    else if (EbmlId(*ElementLevel3) == KaxCodecID::ClassInfos.GlobalId) {
                                        KaxCodecID & CodecID = *static_cast<KaxCodecID*>(ElementLevel3);
                                        CodecID.ReadData(aStream.I_O());
                                        if (string(CodecID) == "V_MPEG4/ISO/AVC" && video_h264No == 0) {
                                            video_h264No = trackNo;
                                        } else if (string(CodecID) == "A_AAC" && audio_aacNo == 0) {
                                            audio_aacNo = trackNo;
                                        } else if (string(CodecID) == "A_AC3" && audio_ac3No == 0) {
                                            audio_ac3No = trackNo;
                                        }
                                        printf("Codec ID: %s\n", string(CodecID).c_str());
                                    } else if (EbmlId(*ElementLevel3) == KaxCodecPrivate::ClassInfos.GlobalId) {
                                        
                                        KaxCodecPrivate & CodecPrivate = *static_cast<KaxCodecPrivate*>(ElementLevel3);
                                        CodecPrivate.ReadData(aStream.I_O());
                                        printf("CodecPrivate Size: %llu\n", CodecPrivate.GetSize());
                                        printf("tracktypenow: %d\n",tracktypenow);
                                        
                                        if (tracktypenow == track_video && video_h264No != 0) {
                                            uint8 data[4] = {0x00, 0x00, 0x00, 0x01};
                                            fwrite(&data, sizeof(uint8), 4, video_file);
                                            int spsLength = *(CodecPrivate.GetBuffer() + 6) * 16 * 16 + *(CodecPrivate.GetBuffer() + 7);
                                            fwrite(CodecPrivate.GetBuffer() + 8, sizeof(unsigned char), spsLength, video_file);
                                            fwrite(&data, sizeof(uint8), 4, video_file);
                                            int ppsLength = *(CodecPrivate.GetBuffer() + spsLength + 9) * 16 * 16 + *(CodecPrivate.GetBuffer() + spsLength + 10);
                                            fwrite(CodecPrivate.GetBuffer() + spsLength + 11, sizeof(unsigned char), ppsLength, video_file);    
                                        }
                                        
                                    } else if (EbmlId(*ElementLevel3) == KaxTrackAudio::ClassInfos.GlobalId) {
                                        printf("KaxTrackAudio\n");
                                        KaxTrackAudio *TrackAudio = static_cast<KaxTrackAudio*>(ElementLevel3);
                                        TrackAudio->Read(aStream, KaxTrackAudio::ClassInfos.Context, UpperElementLevel, ElementLevel3, bAllowDummy);
                                        unsigned int Index0;
                                        for (Index0 = 0; Index0 < TrackAudio->ListSize(); Index0++) {
                                            if ((*TrackAudio)[Index0]->Generic().GlobalId == KaxAudioSamplingFreq::ClassInfos.GlobalId) {
                                                KaxAudioSamplingFreq & SampleFreq = *static_cast<KaxAudioSamplingFreq*>((*TrackAudio)[Index0]);
                                                if (trackNo == audio_aacNo) {
                                                    samplingNum = GetSamplingFrequency(SampleFreq.GetValue());
                                                    printf("KaxAudioSamplingFreq: %f\n",SampleFreq.GetValue());
                                                }
                                            } else if ((*TrackAudio)[Index0]->Generic().GlobalId == KaxAudioChannels::ClassInfos.GlobalId) {
                                                KaxAudioChannels & Channels = *static_cast<KaxAudioChannels*>((*TrackAudio)[Index0]); 
                                                if (trackNo == audio_aacNo) {
                                                    channelsNum = GetChannels(Channels.GetValue());
                                                    printf("KaxAudiChannels: %llu\n", Channels.GetValue());
                                                }
                                            }
                                        }

                                    } else if ((EbmlId(*ElementLevel3) == KaxContentEncodings::ClassInfos.GlobalId)) {
                                        printf("KaxContentEncodings\n");
                                        KaxContentEncodings *ContentEncodings = static_cast<KaxContentEncodings*>(ElementLevel3);
                                        ContentEncodings->Read(aStream, KaxContentEncodings::ClassInfos.Context, UpperElementLevel, ElementLevel3, bAllowDummy);
                                        unsigned int Index0;
                                        for (Index0 = 0; Index0 < ContentEncodings->ListSize(); Index0++) {
                                            if ((*ContentEncodings)[Index0]->Generic().GlobalId == KaxContentEncoding::ClassInfos.GlobalId) {
                                                KaxContentEncoding & ContentEncoding = *static_cast<KaxContentEncoding*>((*ContentEncodings)[Index0]);
                                                unsigned int Index1;
                                                for (Index1 = 0; Index1 < ContentEncoding.ListSize(); Index1++) {
                                                    if (ContentEncoding[Index1]->Generic().GlobalId == KaxContentCompression::ClassInfos.GlobalId) {
                                                        KaxContentCompression & ContentCompression = *static_cast<KaxContentCompression*>(ContentEncoding[Index1]);
                                                        unsigned int Index2;
                                                        for (Index2 = 0; Index2 < ContentCompression.ListSize(); Index2++) {
                                                            if (ContentCompression[Index2]->Generic().GlobalId == KaxContentCompAlgo::ClassInfos.GlobalId) {
                                                                KaxContentCompAlgo & ContentCompAlgo = *static_cast<KaxContentCompAlgo*>(ContentCompression[Index2]);
                                                                if (trackNo == video_h264No) {
                                                                    printf("KaxContentCompAlgo: %llu\n", ContentCompAlgo.GetValue());
                                                                }
                                                            } else if (ContentCompression[Index2]->Generic().GlobalId == KaxContentCompSettings::ClassInfos.GlobalId) {
                                                                KaxContentCompSettings & ContentCompSettings = *static_cast<KaxContentCompSettings*>(ContentCompression[Index2]);
                                                                if (trackNo == video_h264No) {
                                                                    printf("KaxContentCompSettings: %x\n",uint16(ContentCompSettings));
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                     
                                    if (UpperElementLevel > 0) {
                                        assert(0 == 1); // impossible to be here ?
                                        UpperElementLevel--;
                                        delete ElementLevel2;
                                        ElementLevel2 = ElementLevel3;
                                        if (UpperElementLevel > 0)
                                            break;
                                    } else {
                                        ElementLevel3->SkipData(aStream, ElementLevel3->Generic().Context);
                                        delete ElementLevel3;
                                        
                                        ElementLevel3 = aStream.FindNextElement(ElementLevel2->Generic().Context, UpperElementLevel, 0xFFFFFFFFL, bAllowDummy);
                                    }
                                      
                                }
                            }
                            if (UpperElementLevel > 0) {
                                UpperElementLevel--;
                                delete ElementLevel2;
                                ElementLevel2 = ElementLevel3;
                                if (UpperElementLevel > 0)
                                    break;
                            } else {
                                ElementLevel2->SkipData(aStream, ElementLevel2->Generic().Context);
                                delete ElementLevel2;
                                
                                ElementLevel2 = aStream.FindNextElement(ElementLevel1->Generic().Context, UpperElementLevel, 0xFFFFFFFFL, bAllowDummy);
                            }
                        }
                    }
                    
                    else if (EbmlId(*ElementLevel1) == KaxInfo::ClassInfos.GlobalId) {
                        printf("\n- Segment Informations: ");
                        for (unsigned int i = 0; i < EbmlId(*ElementLevel1).Length; i++)
                        {
                            printf("[%02X]", (EbmlId(*ElementLevel1).Value >> (8*(3-i))) & 0xFF);
                        }
                        printf("\n");
                        SegmentInfo = static_cast<KaxInfo *>(ElementLevel1);
                        
                        // read the data we care about in matroska
                        /// \todo There should be a way to get the default values of the elements not defined
                        ElementLevel2 = aStream.FindNextElement(ElementLevel1->Generic().Context, UpperElementLevel, 0xFFFFFFFFL, bAllowDummy);
                        while (ElementLevel2 != NULL) {
                            if (UpperElementLevel > 0) {
                                break;
                            }
                            if (UpperElementLevel < 0) {
                                UpperElementLevel = 0;
                            }
                            if (EbmlId(*ElementLevel2) == KaxTimecodeScale::ClassInfos.GlobalId) {
                                KaxTimecodeScale *TimeScale = static_cast<KaxTimecodeScale*>(ElementLevel2);
                                TimeScale->ReadData(aStream.I_O());
                                printf("Timecode Scale: %d\n", uint32(*TimeScale));
                                TimecodeScale = uint64(*TimeScale);
                            } else if (EbmlId(*ElementLevel2) == KaxDuration::ClassInfos.GlobalId) {
                                printf("Segment duration:\n");
                            } else if (EbmlId(*ElementLevel2) == KaxDateUTC::ClassInfos.GlobalId) {
                                printf("Date UTC:\n");
                            } else if (EbmlId(*ElementLevel2) == KaxTitle::ClassInfos.GlobalId) {
                                printf("Title:\n");
                            } else if (EbmlId(*ElementLevel2) == KaxMuxingApp::ClassInfos.GlobalId) {
                                KaxMuxingApp *pApp = static_cast<KaxMuxingApp*>(ElementLevel2);
                                pApp->ReadData(aStream.I_O());
                                printf("Muxing App : %ls\n", UTFstring(*pApp).c_str());
                            } else if (EbmlId(*ElementLevel2) == KaxWritingApp::ClassInfos.GlobalId) {
                                KaxWritingApp *pApp = static_cast<KaxWritingApp*>(ElementLevel2);
                                pApp->ReadData(aStream.I_O());
                                printf("Writing App : %ls\n", UTFstring(*pApp).c_str());
                            }
                            
                            if (UpperElementLevel > 0) {
                                UpperElementLevel--;
                                delete ElementLevel2;
                                ElementLevel2 = ElementLevel3;
                                if (UpperElementLevel > 0)
                                    break;
                            } else {
                                ElementLevel2->SkipData(aStream, ElementLevel2->Generic().Context);
                                delete ElementLevel2;
                                
                                ElementLevel2 = aStream.FindNextElement(ElementLevel1->Generic().Context, UpperElementLevel, 0xFFFFFFFFL, bAllowDummy);
                            }
                        }
                    }
                    
                    else if (EbmlId(*ElementLevel1) == KaxCluster::ClassInfos.GlobalId) {
                        printf("\n- Segment Clusters found: ");
                        for (unsigned int i = 0; i < EbmlId(*ElementLevel1).Length; i++)
                        {
                            printf("[%02X]", (EbmlId(*ElementLevel1).Value >> (8*(3-i))) & 0xFF);
                        }
                        printf("\n");
                        SegmentCluster = static_cast<KaxCluster *>(ElementLevel1);
                        //					SegmentCluster->ClearElement();
                        uint32 ClusterTimecode;
                        EbmlCrc32 *pChecksum = NULL;
                        uint32 SizeInCrc;
                        uint64 CrcPositionStart = 0;
                        
                        // read blocks and discard the ones we don't care about
                        ElementLevel2 = aStream.FindNextElement(ElementLevel1->Generic().Context, UpperElementLevel, 0xFFFFFFFFL, bAllowDummy);
                        while (ElementLevel2 != NULL) {
                            if (UpperElementLevel > 0) {
                                break;
                            }
                            if (UpperElementLevel < 0) {
                                UpperElementLevel = 0;
                            }
                          //  printf("EbmlId: %x\nLength: %llu\n", EbmlId(*ElementLevel2).Value, ElementLevel2->GetSize());
                            if (EbmlId(*ElementLevel2) == KaxClusterTimecode::ClassInfos.GlobalId) {
                                printf("Cluster timecode found\n");
                                KaxClusterTimecode & ClusterTime = *static_cast<KaxClusterTimecode*>(ElementLevel2);
                                ClusterTime.ReadData(aStream.I_O());
                                ClusterTimecode = uint32(ClusterTime);
                                SegmentCluster->InitTimecode(ClusterTimecode, TimecodeScale);
                            } else if (EbmlId(*ElementLevel2) == KaxBlockGroup::ClassInfos.GlobalId) {
                                printf("Block Group found Size: %llu\n", ElementLevel2->GetSize());
                                // read the data we care about in matroska
                                /// \todo There should be a way to get the default values of the elements not defined
                                ElementLevel3 = aStream.FindNextElement(ElementLevel2->Generic().Context, UpperElementLevel, 0xFFFFFFFFL, bAllowDummy);
                                while (ElementLevel3 != NULL) {
                                    if (UpperElementLevel > 0) {
                                        break;
                                    }
                                    if (UpperElementLevel < 0) {
                                        UpperElementLevel = 0;
                                    }
                                    if (EbmlId(*ElementLevel3) == KaxBlock::ClassInfos.GlobalId) {
                                        printf("not Block Data Size: %llu\n", ElementLevel3->GetSize());
                                        KaxBlock & DataBlock = *static_cast<KaxBlock*>(ElementLevel3);
                                        DataBlock.ReadData(aStream.I_O(), SCOPE_ALL_DATA);
                                        DataBlock.SetParent(*SegmentCluster);
                                        printf("   Track # %d -- %d frames -- Timecode %llu\n",DataBlock.TrackNum(), DataBlock.NumberFrames(), DataBlock.GlobalTimecode());
                                        
                                        //h264 parser
                                        if (DataBlock.TrackNum() == video_h264No && video_h264No != 0) {
                                             for (unsigned int i = 0; i< DataBlock.NumberFrames(); i++) {
                                                    printf("DataBlock.GetBuffer(%d).Size(): HEX:%x DEC: %d\n", i, DataBlock.GetBuffer(i).Size(),  DataBlock.GetBuffer(i).Size());
                                                    uint8 blockheader[4] = {0x00, 0x00, 0x00, 0x01};
                                                    int firstHeaderLength = 0, tempLength = 0;
                                                    while(tempLength < DataBlock.GetBuffer(i).Size()) {
                                                        fwrite(&blockheader, sizeof(unsigned char), 4, video_file);
                                                        firstHeaderLength = (*(DataBlock.GetBuffer(i).Buffer() + tempLength)) * 16 * 16 * 16 * 16 * 16 * 16 + (*(DataBlock.GetBuffer(i).Buffer() + tempLength + 1)) * 16 * 16 * 16 * 16 + (*(DataBlock.GetBuffer(i).Buffer() + tempLength + 2)) * 16 * 16 + (*(DataBlock.GetBuffer(i).Buffer() + tempLength + 3));
                                                        printf("firstHeaderLength: %d\n", firstHeaderLength);
                                                        fwrite(DataBlock.GetBuffer(i).Buffer() + tempLength + 4, sizeof(unsigned char), firstHeaderLength, video_file);
                                                        tempLength += firstHeaderLength + 4;
                                                    }
                                                }
                                        } else if (DataBlock.TrackNum() == audio_ac3No && audio_ac3No != 0 && audio_aacNo == 0) {
                                            for (unsigned int i = 0; i < DataBlock.NumberFrames(); i++) {
                                                fwrite(DataBlock.GetBuffer(i).Buffer(), sizeof(unsigned char), DataBlock.GetBuffer(i).Size(), audio_file);
                                                return 0;
                                            }
                                            
                                        } else if (DataBlock.TrackNum() == audio_aacNo && audio_aacNo != 0) {
                                            for (unsigned int i = 0; i < DataBlock.NumberFrames(); i++) {
                                                int aacHead[56];
                                                //syncword 12btye
                                                for (unsigned int j = 0; j < 12; j++) {
                                                    aacHead[j] = 1;
                                                }
                                                
                                                //ID 1btye
                                                aacHead[12] = 0;
                                                
                                                //layer 2btye
                                                aacHead[13] = 0;
                                                aacHead[14] = 0;
                                                
                                                //protection_absent 1btye
                                                aacHead[15] = 1;
                                                
                                                //profile_objecttype 2btye
                                                aacHead[16] = 0;
                                                aacHead[17] = 1;
                                                
                                                //sample_rate_index 4btye
                                                int samplingNum_temp = samplingNum;
                                                for (unsigned int j = 0, HexNum = 8; j < 4; j++, HexNum = HexNum / 2) {
                                                    if (samplingNum_temp / HexNum == 0) {
                                                        aacHead[18 + j] = 0;
                                                    } else {
                                                        aacHead[18 + j] = 1;
                                                        samplingNum_temp = samplingNum_temp % HexNum;
                                                    }
                                                }
                                                
                                                //private_bit 1btye
                                                aacHead[22] = 0;
                                                
                                                //channel_configuration 3btye
                                                int channelNum_temp = channelsNum;
                                                for (unsigned int j = 0, HexNum = 4; j < 3; j++, HexNum = HexNum / 2) {
                                                    if (channelNum_temp / HexNum == 0) {
                                                        aacHead[23 + j] = 0;
                                                    } else {
                                                        aacHead[23 + j] = 1;
                                                        channelNum_temp = channelNum_temp % HexNum;
                                                    }
                                                }
                                                
                                                //original_copy 1btye
                                                aacHead[26] = 0;
                                                
                                                //home
                                                aacHead[27] = 0;
                                                
                                                //copyright_identification_bit 1btye
                                                aacHead[28] = 0;
                                                
                                                //copyright_identification_start
                                                aacHead[29] = 0;
                                                
                                                //aac_frame_length 13btye
                                                int frame_length = 7 + DataBlock.GetBuffer(i).Size();
                                                for (unsigned int j = 0, HexNum = 4096; j < 13; j++, HexNum = HexNum / 2) {
                                                    if (frame_length / HexNum == 0) {
                                                        aacHead[30 + j] = 0;
                                                    } else {
                                                        aacHead[30 + j] = 1;
                                                        frame_length = frame_length % HexNum;
                                                    }
                                                }
                                                
                                                //adts_buffer_fullness 11btye
                                                for (unsigned int j = 0; j < 11; j++) {
                                                    aacHead[43 + j] = 1;
                                                }
                                                
                                                //number_of_raw_data_blocks_in_frame
                                                aacHead[54] = 0;
                                                aacHead[55] = 0;
                                                
                                                //aachead to Hex
                                                for (unsigned int j = 0; j < 56; j = j + 8) {
                                                    int result = aacHead[j] * 128 + aacHead[j + 1] * 64 + aacHead[j + 2] * 32 + aacHead[j + 3] * 16 + aacHead[j + 4] * 8 + aacHead[j + 5] * 4 + aacHead[j + 6] * 2 + aacHead[j + 7];
                                                    printf("%x ",result);
                                                    fwrite(&result, sizeof(unsigned char), 1, audio_file);
                                                }
                                                printf("\n");
                                                
                                                fwrite(DataBlock.GetBuffer(i).Buffer(), sizeof(unsigned char), DataBlock.GetBuffer(i).Size(), audio_file);
                                            }
                                           
                                        }
#if MATROSKA_VERSION >= 2
                                    } else if (EbmlId(*ElementLevel3) == KaxBlockVirtual::ClassInfos.GlobalId) {
                                        printf(" Virtual Block:\n");
                                    } else if (EbmlId(*ElementLevel3) == KaxReferenceVirtual::ClassInfos.GlobalId) {
                                        printf(" Virtual Reference:\n");
#endif // MATROSKA_VERSION
                                    } else if (EbmlId(*ElementLevel3) == KaxReferencePriority::ClassInfos.GlobalId) {
                                        printf("  Reference priority:\n");
                                    } else if (EbmlId(*ElementLevel3) == KaxReferenceBlock::ClassInfos.GlobalId) {
                                        KaxReferenceBlock & RefTime = *static_cast<KaxReferenceBlock*>(ElementLevel3);
                                        RefTime.ReadData(aStream.I_O());
                                        printf("  Reference frame at scaled (%d) timecode %d\n", int32(RefTime), int32(int64(RefTime) * TimecodeScale));
                                    } else if (EbmlId(*ElementLevel3) == KaxBlockDuration::ClassInfos.GlobalId) {
                                        KaxBlockDuration & BlockDuration = *static_cast<KaxBlockDuration*>(ElementLevel3);
                                        BlockDuration.ReadData(aStream.I_O());
                                        printf("  Block Duration %d scaled ticks : %llu ns\n", uint32(BlockDuration), uint32(BlockDuration) * TimecodeScale);
                                    }
                                    if (UpperElementLevel > 0) {
                                        UpperElementLevel--;
                                        delete ElementLevel3;
                                        ElementLevel3 = ElementLevel4;
                                        if (UpperElementLevel > 0)
                                            break;
                                    } else {
                                        ElementLevel3->SkipData(aStream, ElementLevel3->Generic().Context);
                                        
                                        ElementLevel3 = aStream.FindNextElement(ElementLevel2->Generic().Context, UpperElementLevel, 0xFFFFFFFFL, bAllowDummy);
                                    }
                                }
                            } else if (EbmlId(*ElementLevel2) == EbmlCrc32::ClassInfos.GlobalId) {
                                printf("Cluster CheckSum !\n");
                                pChecksum = static_cast<EbmlCrc32*>(ElementLevel2);
                                pChecksum->ReadData(aStream.I_O());
                                SegmentCluster->ForceChecksum( pChecksum->GetCrc32() ); // not use later
                                SizeInCrc = 0;
                                CrcPositionStart = aStream.I_O().getFilePointer();
                            }else if (EbmlId(*ElementLevel2) == KaxSimpleBlock::ClassInfos.GlobalId) {
                                
                                printf("Simple Block Data Size: %llu\n", ElementLevel2->GetSize());
                                
                                KaxBlock & DataBlock = *static_cast<KaxBlock*>(ElementLevel2);
                                DataBlock.ReadData(aStream.I_O(), SCOPE_ALL_DATA);
                                DataBlock.SetParent(*SegmentCluster);
                                printf("   Track # %d -- %d frames -- Timecode %llu\n",DataBlock.TrackNum(), DataBlock.NumberFrames(), DataBlock.GlobalTimecode());
                                if (DataBlock.TrackNum() == video_h264No && video_h264No != 0) {
                                    printf("DataLacing %d\n", DataBlock.GetBestLacingType());
                                    for (unsigned int i = 0; i< DataBlock.NumberFrames(); i++) {
                                            printf("DataBlock.GetBuffer(%d).Size(): HEX:%x DEC: %d\n", i, DataBlock.GetBuffer(i).Size(),  DataBlock.GetBuffer(i).Size());
                                            uint8 blockheader[4] = {0x00, 0x00, 0x00, 0x01};
                                            int firstHeaderLength = 0, tempLength = 0 , NaluLength = 0;
                                            while(tempLength < DataBlock.GetBuffer(i).Size()) {
                                                NaluLength = 0;
                                                fwrite(&blockheader, sizeof(unsigned char), 4, video_file);
                                                if (tempLength == 0) {
                                                    firstHeaderLength = (*DataBlock.GetBuffer(i).Buffer()) * 16 * 16 * 16 * 16  + (*(DataBlock.GetBuffer(i).Buffer() + 1)) * 16 * 16 + (*(DataBlock.GetBuffer(i).Buffer() + 2));
                                                    NaluLength = 3;
                                                } else {
                                                    firstHeaderLength = (*(DataBlock.GetBuffer(i).Buffer() + tempLength)) * 16 * 16 * 16 * 16 * 16 * 16 + (*(DataBlock.GetBuffer(i).Buffer() + tempLength + 1)) * 16 * 16 * 16 * 16 + (*(DataBlock.GetBuffer(i).Buffer() + tempLength + 2)) * 16 * 16 + (*(DataBlock.GetBuffer(i).Buffer() + tempLength + 3));
                                                    NaluLength = 4;
                                                }
                                                printf("firstHeaderLength: %d\n", firstHeaderLength);
                                                fwrite(DataBlock.GetBuffer(i).Buffer() + tempLength + NaluLength, sizeof(unsigned char), firstHeaderLength, video_file);
                                                tempLength += firstHeaderLength + NaluLength;
                                            }
                                    }
                                } else if (DataBlock.TrackNum() == audio_aacNo && audio_aacNo != 0) {
                                    
                                    for (unsigned int i = 0; i < DataBlock.NumberFrames(); i++) {
                                        int aacHead[56];
                                        //syncword 12btye
                                        for (unsigned int j = 0; j < 12; j++) {
                                            aacHead[j] = 1;
                                        }
                                        
                                        //ID 1btye
                                        aacHead[12] = 0;
                                        
                                        //layer 2btye
                                        aacHead[13] = 0;
                                        aacHead[14] = 0;
                                        
                                        //protection_absent 1btye
                                        aacHead[15] = 1;
                                        
                                        //profile_objecttype 2btye
                                        aacHead[16] = 0;
                                        aacHead[17] = 1;
                                        
                                        //sample_rate_index 4btye
                                        int samplingNum_temp = samplingNum;
                                        for (unsigned int j = 0, HexNum = 8; j < 4; j++, HexNum = HexNum / 2) {
                                            if (samplingNum_temp / HexNum == 0) {
                                                aacHead[18 + j] = 0;
                                            } else {
                                                aacHead[18 + j] = 1;
                                                samplingNum_temp = samplingNum_temp % HexNum;
                                            }
                                        }
                                                                        
                                        //private_bit 1btye
                                        aacHead[22] = 0;
                                        
                                        //channel_configuration 3btye
                                        int channelNum_temp = channelsNum;
                                        for (unsigned int j = 0, HexNum = 4; j < 3; j++, HexNum = HexNum / 2) {
                                            if (channelNum_temp / HexNum == 0) {
                                                aacHead[23 + j] = 0;
                                            } else {
                                                aacHead[23 + j] = 1;
                                                channelNum_temp = channelNum_temp % HexNum;
                                            }
                                        }
                                                                            
                                        //original_copy 1btye
                                        aacHead[26] = 0;
                                        
                                        //home
                                        aacHead[27] = 0;
                                        
                                        //copyright_identification_bit 1btye
                                        aacHead[28] = 0;
                                        
                                        //copyright_identification_start
                                        aacHead[29] = 0;
                                        
                                        //aac_frame_length 13btye
                                        int frame_length = 7 + DataBlock.GetBuffer(i).Size();
                                        for (unsigned int j = 0, HexNum = 4096; j < 13; j++, HexNum = HexNum / 2) {
                                            if (frame_length / HexNum == 0) {
                                                aacHead[30 + j] = 0;
                                            } else {
                                                aacHead[30 + j] = 1;
                                                frame_length = frame_length % HexNum;
                                            }
                                        }
                                        
                                        //adts_buffer_fullness 11btye
                                        for (unsigned int j = 0; j < 11; j++) {
                                            aacHead[43 + j] = 1;
                                        }
                                        
                                        //number_of_raw_data_blocks_in_frame
                                        aacHead[54] = 0;
                                        aacHead[55] = 0;
                                        
                                        //aachead to Hex
                                        for (unsigned int j = 0; j < 56; j = j + 8) {
                                            int result = aacHead[j] * 128 + aacHead[j + 1] * 64 + aacHead[j + 2] * 32 + aacHead[j + 3] * 16 + aacHead[j + 4] * 8 + aacHead[j + 5] * 4 + aacHead[j + 6] * 2 + aacHead[j + 7];
                                            printf("%x ",result);
                                            fwrite(&result, sizeof(unsigned char), 1, audio_file);
                                        }
                                        printf("\n");
                                        
                                        fwrite(DataBlock.GetBuffer(i).Buffer(), sizeof(unsigned char), DataBlock.GetBuffer(i).Size(), audio_file);
                                    }
                                     
                                } else if (DataBlock.TrackNum() == audio_ac3No && audio_ac3No != 0 && audio_aacNo == 0) {
                                    for (unsigned int i = 0; i < DataBlock.NumberFrames(); i++) {
                                        fwrite(DataBlock.GetBuffer(i).Buffer(), sizeof(unsigned char), DataBlock.GetBuffer(i).Size(), audio_file);
                                    }
                                }
                                 
                            }
                            
                            if (UpperElementLevel > 0) {
                                UpperElementLevel--;
                                delete ElementLevel2;
                                ElementLevel2 = ElementLevel3;
                                if (UpperElementLevel > 0)
                                    break;
                            } else {
                                ElementLevel2->SkipData(aStream, ElementLevel2->Generic().Context);
                                if (ElementLevel2 != pChecksum)
                                    delete ElementLevel2;
                                
                                ElementLevel2 = aStream.FindNextElement(ElementLevel1->Generic().Context, UpperElementLevel, 0xFFFFFFFFL, bAllowDummy);
                            }
                        } 
                        
                        if (pChecksum != NULL) {
                            EbmlCrc32 ComputedChecksum;
                            uint64 CurrPosition = aStream.I_O().getFilePointer();
                            uint64 CrcPositionEnd = ElementLevel2->GetElementPosition();
                            binary *SupposedBufferInCrc = new binary [CrcPositionEnd - CrcPositionStart];
                            aStream.I_O().setFilePointer(CrcPositionStart);
                            aStream.I_O().readFully(SupposedBufferInCrc, CrcPositionEnd - CrcPositionStart);
                            aStream.I_O().setFilePointer(CurrPosition);
                            ComputedChecksum.FillCRC32(SupposedBufferInCrc, CrcPositionEnd - CrcPositionStart);
                            delete [] SupposedBufferInCrc;
                            if (pChecksum->GetCrc32() == ComputedChecksum.GetCrc32()) {
                                printf(" ++ CheckSum verification succeeded ++");
                            } else {
                                printf(" ++ CheckSum verification FAILED !!! ++");
                            }
                            delete pChecksum;
                            pChecksum = NULL;
                        }
                    }
                    else if (EbmlId(*ElementLevel1) == KaxCues::ClassInfos.GlobalId) {
                        printf("\n- Cue entries found: ");
                        for (unsigned int i = 0; i < EbmlId(*ElementLevel1).Length; i++)
                        {
                            printf("[%02X]", (EbmlId(*ElementLevel1).Value >> (8*(3-i))) & 0xFF);
                        }
                        printf("\n");
                        CuesEntry = static_cast<KaxCues *>(ElementLevel1);
                        CuesEntry->SetGlobalTimecodeScale(TimecodeScale);
                        // read everything in memory
                        CuesEntry->Read(aStream, KaxCues::ClassInfos.Context, UpperElementLevel, ElementLevel2, bAllowDummy); // build the entries in memory
                        if (CuesEntry->CheckMandatory()) {
                            printf("  * All mandatory elements found *\n");
                        } else {
                            printf("  * Some mandatory elements ar missing !!! *\n");
                        }
                        CuesEntry->Sort();
                        // display the elements read
                        unsigned int Index0;
                        for (Index0 = 0; Index0<CuesEntry->ListSize() ;Index0++) {
                            if ((*CuesEntry)[Index0]->Generic().GlobalId == KaxCuePoint::ClassInfos.GlobalId) {
                                printf(" Cue Point\n");
                                
                                KaxCuePoint & CuePoint = *static_cast<KaxCuePoint *>((*CuesEntry)[Index0]);
                                unsigned int Index1;
                                for (Index1 = 0; Index1<CuePoint.ListSize() ;Index1++) {
                                    if (CuePoint[Index1]->Generic().GlobalId == KaxCueTime::ClassInfos.GlobalId) {
                                        KaxCueTime & CueTime = *static_cast<KaxCueTime *>(CuePoint[Index1]);
                                        printf("  Time: %llu\n", uint64(CueTime) * TimecodeScale);
                                    } else if (CuePoint[Index1]->Generic().GlobalId == KaxCueTrackPositions::ClassInfos.GlobalId) {
                                        KaxCueTrackPositions & CuePos = *static_cast<KaxCueTrackPositions *>(CuePoint[Index1]);
                                        printf("  Positions:\n");
                                        
                                        unsigned int Index2;
                                        for (Index2 = 0; Index2<CuePos.ListSize() ;Index2++) {
                                            if (CuePos[Index2]->Generic().GlobalId == KaxCueTrack::ClassInfos.GlobalId) {
                                                KaxCueTrack & CueTrack = *static_cast<KaxCueTrack *>(CuePos[Index2]);
                                                printf("   Track: %d\n", uint16(CueTrack));
                                            } else if (CuePos[Index2]->Generic().GlobalId == KaxCueClusterPosition::ClassInfos.GlobalId) {
                                                KaxCueClusterPosition & CuePoss = *static_cast<KaxCueClusterPosition *>(CuePos[Index2]);
                                                printf("   Cluster position: %llu\n", uint64(CuePoss));
#if MATROSKA_VERSION >= 2
                                            } else if (CuePos[Index2]->Generic().GlobalId == KaxCueReference::ClassInfos.GlobalId) {
                                                KaxCueReference & CueRefs = *static_cast<KaxCueReference *>(CuePos[Index2]);
                                                printf("   Reference:\n");
                                                
                                                unsigned int Index3;
                                                for (Index3 = 0; Index3<CueRefs.ListSize() ;Index3++) {
                                                    if (CueRefs[Index3]->Generic().GlobalId == KaxCueRefTime::ClassInfos.GlobalId) {
                                                        KaxCueRefTime & CueTime = *static_cast<KaxCueRefTime *>(CueRefs[Index3]);
                                                        printf("    Time: %d\n", uint32(CueTime));
                                                    } else if (CueRefs[Index3]->Generic().GlobalId == KaxCueRefCluster::ClassInfos.GlobalId) {
                                                        KaxCueRefCluster & CueClust = *static_cast<KaxCueRefCluster *>(CueRefs[Index3]);
                                                        printf("    Cluster position: %llu\n", uint64(CueClust));
                                                    } else {
                                                        printf("    - found %s\n", CueRefs[Index3]->Generic().DebugName);
                                                    }
                                                }
#endif // MATROSKA_VERSION
                                            } else {
                                                printf("   - found %s\n", CuePos[Index2]->Generic().DebugName);
                                            }
                                        }
                                    } else {
                                        printf("  - found %s\n", CuePoint[Index1]->Generic().DebugName);
                                    }
                                }
                            } else {
                                printf(" - found %s\n", (*CuesEntry)[Index0]->Generic().DebugName);
                            }
                        }
                    }
                    else if (EbmlId(*ElementLevel1) == KaxSeekHead::ClassInfos.GlobalId) {
                        printf("\n- Meta Seek Head found: ");
                        for (unsigned int i = 0; i < EbmlId(*ElementLevel1).Length; i++)
                        {
                            printf("[%02X]", (EbmlId(*ElementLevel1).Value >> (8*(3-i))) & 0xFF);
                        }
                        printf("\n");
                        MetaSeek = static_cast<KaxSeekHead *>(ElementLevel1);
                        // read it in memory
                        MetaSeek->Read(aStream, KaxSeekHead::ClassInfos.Context, UpperElementLevel, ElementLevel2, bAllowDummy);
                        if (MetaSeek->CheckMandatory()) {
                            printf("  * All mandatory elements found *\n");
                        } else {
                            printf("  * Some mandatory elements ar missing !!! *\n");
                        }
                        unsigned int Index0;
                        for (Index0 = 0; Index0<MetaSeek->ListSize() ;Index0++) {
                            if ((*MetaSeek)[Index0]->Generic().GlobalId == KaxSeek::ClassInfos.GlobalId) {
                                printf("   Seek Point\n");
                                KaxSeek & SeekPoint = *static_cast<KaxSeek *>((*MetaSeek)[Index0]);
                                unsigned int Index1;
                                for (Index1 = 0; Index1<SeekPoint.ListSize() ;Index1++) {
                                    if (SeekPoint[Index1]->Generic().GlobalId == KaxSeekID::ClassInfos.GlobalId) {
                                        KaxSeekID * SeekID = static_cast<KaxSeekID *>(SeekPoint[Index1]);
                                        printf("    Seek ID ");
                                        for (unsigned int i=0; i<SeekID->GetSize(); i++) {
                                            printf("[%02X]", SeekID->GetBuffer()[i]);
                                        }
                                        printf("\n");
                                    } else if (SeekPoint[Index1]->Generic().GlobalId == KaxSeekPosition::ClassInfos.GlobalId) {
                                        KaxSeekPosition * SeekPos = static_cast<KaxSeekPosition *>(SeekPoint[Index1]);
                                        printf("    Seek position %d\n", uint32(*SeekPos));
                                    }
                                }
                            }
                        }
                    } else if (EbmlId(*ElementLevel1) == KaxChapters::ClassInfos.GlobalId) {
                        printf("\n- Chapters found: ");
                        for (unsigned int i = 0; i < EbmlId(*ElementLevel1).Length; i++)
                        {
                            printf("[%02X]", (EbmlId(*ElementLevel1).Value >> (8*(3-i))) & 0xFF);
                        }
                        printf("\n");
                        Chapters = static_cast<KaxChapters *>(ElementLevel1);
                        // read it in memory
                        Chapters->Read(aStream, KaxChapters::ClassInfos.Context, UpperElementLevel, ElementLevel2, bAllowDummy);
                        if (Chapters->CheckMandatory()) {
                            printf("  * All mandatory elements found *\n");
                        } else {
                            printf("  * Some mandatory elements ar missing !!! *\n");
                        }
                        unsigned int Index0;
                        for (Index0 = 0; Index0<Chapters->ListSize() ;Index0++) {
                            if ((*Chapters)[Index0]->Generic().GlobalId == KaxEditionEntry::ClassInfos.GlobalId) {
                                printf("   Edition\n");
                                KaxEditionEntry & Edition = *static_cast<KaxEditionEntry *>((*Chapters)[Index0]);
                                unsigned int Index2;
                                for (Index2 = 0; Index2<Edition.ListSize() ;Index2++) {
                                    if (Edition[Index2]->Generic().GlobalId == KaxChapterAtom::ClassInfos.GlobalId) {
                                        printf("     Chapter Atom\n");
                                        KaxChapterAtom & aChapterAtom = *static_cast<KaxChapterAtom *>(Edition[Index2]);
                                        unsigned int Index3;
                                        for (Index3 = 0; Index3<aChapterAtom.ListSize() ;Index3++) {
                                            if (aChapterAtom[Index3]->Generic().GlobalId == KaxChapterUID::ClassInfos.GlobalId) {
                                                printf("      Chapter UID 0x%08x\n", uint32(*static_cast<EbmlUInteger *>(aChapterAtom[Index3])) );
                                            } else if (aChapterAtom[Index3]->Generic().GlobalId == KaxChapterTimeStart::ClassInfos.GlobalId) {
                                                printf("      Time Start %d\n", uint32(*static_cast<EbmlUInteger *>(aChapterAtom[Index3])) );
                                            } else if (aChapterAtom[Index3]->Generic().GlobalId == KaxChapterTimeEnd::ClassInfos.GlobalId) {
                                                printf("      Time End %d ns\n", uint32(*static_cast<EbmlUInteger *>(aChapterAtom[Index3])) );
                                            } else if (aChapterAtom[Index3]->Generic().GlobalId == KaxChapterTrack::ClassInfos.GlobalId) {
                                                printf("      Track list\n");
                                            } else if (aChapterAtom[Index3]->Generic().GlobalId == KaxChapterDisplay::ClassInfos.GlobalId) {
                                                printf("      Display info\n");
                                                KaxChapterDisplay & aDisplay = *static_cast<KaxChapterDisplay *>(aChapterAtom[Index3]);
                                                unsigned int Index4;
                                                for (Index4 = 0; Index4<aDisplay.ListSize() ;Index4++) {
                                                    if (aDisplay[Index4]->Generic().GlobalId == KaxChapterString::ClassInfos.GlobalId) {
                                                        printf("       Display \"%ls\"\n", UTFstring(*static_cast<EbmlUnicodeString *>(aDisplay[Index4])).c_str() );
                                                    } else if (aDisplay[Index4]->Generic().GlobalId == KaxChapterLanguage::ClassInfos.GlobalId) {
                                                        printf("       For language \"%s\"\n", std::string(*static_cast<EbmlString *>(aDisplay[Index4])).c_str() );
                                                    } else if (aDisplay[Index4]->Generic().GlobalId == KaxChapterCountry::ClassInfos.GlobalId) {
                                                        printf("       For country \"%s\"\n", std::string(*static_cast<EbmlString *>(aDisplay[Index4])).c_str() );
                                                    } else if (aDisplay[Index4]->IsDummy()) {
                                                        printf("       Dummy !!!\n");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else if (EbmlId(*ElementLevel1) == KaxTags::ClassInfos.GlobalId) {
                        printf("\n- Tags found: ");
                        for (unsigned int i = 0; i < EbmlId(*ElementLevel1).Length; i++)
                        {
                            printf("[%02X]", (EbmlId(*ElementLevel1).Value >> (8*(3-i))) & 0xFF);
                        }
                        printf("\n");
                        AllTags = static_cast<KaxTags *>(ElementLevel1);
                        // read it in memory
                        AllTags->Read(aStream, KaxTags::ClassInfos.Context, UpperElementLevel, ElementLevel2, bAllowDummy);
                        if (AllTags->CheckMandatory()) {
                            printf("  * All mandatory elements found *\n");
                        } else {
                            printf("  * Some mandatory elements ar missing !!! *\n");
                        }
                        unsigned int Index0;
                        for (Index0 = 0; Index0<AllTags->ListSize() ;Index0++) {
                            if ((*AllTags)[Index0]->Generic().GlobalId == KaxTag::ClassInfos.GlobalId) {
                                printf("   Tag:\n");
                                KaxTag & TagElt = *static_cast<KaxTag *>((*AllTags)[Index0]);
                                unsigned int Index1;
                                for (Index1 = 0; Index1<TagElt.ListSize() ;Index1++) {
                                    // 								bool bRemoved = false, bRemovedDone = true;
                                    if (TagElt[Index1]->Generic().GlobalId == KaxTagTargets::ClassInfos.GlobalId) {
                                        printf("    Targets:\n");
                                        KaxTagTargets & Targets = *static_cast<KaxTagTargets *>(TagElt[Index1]);
                                        unsigned int Index2;
                                        for (Index2 = 0; Index2<Targets.ListSize() ;Index2++) {
                                            if (Targets[Index2]->Generic().GlobalId == KaxTagTrackUID::ClassInfos.GlobalId) {
#ifndef TEST_REMOVE
                                                printf("     Track UID:\n");
#else // TEST_REMOVE
                                                printf("     Track UID (will be removed)\n");
                                                /*************** Test to remove an element ***************/
                                                Targets.Remove(Index2);
                                                bRemoved = true;
                                                bRemovedDone = false;
                                                Index2--;
                                                Index1--;
#endif // TEST_REMOVE
                                            } else if (Targets[Index2]->Generic().GlobalId == KaxTagChapterUID::ClassInfos.GlobalId) {
                                                printf("     Chapter UID:\n");
#if 0
                                            } else if (Targets[Index2]->Generic().GlobalId == KaxTagMultiComment::ClassInfos.GlobalId) {
                                                printf("     Comment:\n");
                                                KaxTagMultiComment & Comment = *static_cast<KaxTagMultiComment *>(Targets[Index2]);
                                                unsigned int Index3;
                                                for (Index3 = 0; Index3<Comment.ListSize() ;Index3++) {
                                                    if (Comment[Index3]->Generic().GlobalId == KaxTagMultiCommentName::ClassInfos.GlobalId) {
                                                        KaxTagMultiCommentName & CommentName = *static_cast<KaxTagMultiCommentName *>(Comment[Index3]);
                                                        printf("      Comment Name \"%s\"\n", std::string(CommentName).c_str());
                                                    }	
                                                }
                                                //										} else if (Targets[Index2]->Generic().GlobalId == DummyRawElement::ClassInfos.GlobalId) {
#endif
                                            }
                                        }
#ifdef TEST_REMOVE
                                        if (bRemoved) {
                                            printf("    -- Again After Deletion --\n");
                                            bRemoved = false;
                                        } else if (bRemovedDone) {
                                            printf("    -- Done --\n");
                                        }
#endif // TEST_REMOVE
#if 0
                                    } else if (TagElt[Index1]->Generic().GlobalId == KaxTagGeneral::ClassInfos.GlobalId) {
                                        printf("    General:\n");
                                        KaxTagGeneral & General = *static_cast<KaxTagGeneral *>(TagElt[Index1]);
                                        unsigned int Index2;
                                        for (Index2 = 0; Index2<General.ListSize() ;Index2++) {
                                            if (General[Index2]->Generic().GlobalId == KaxTagSubject::ClassInfos.GlobalId) {
                                                printf("     Subject:\n");
                                            } else if (General[Index2]->Generic().GlobalId == KaxTagBibliography::ClassInfos.GlobalId) {
                                                printf("     Bibliography:\n");
                                            } else if (General[Index2]->Generic().GlobalId == KaxTagLanguage::ClassInfos.GlobalId) {
                                                printf("     Language:\n");
                                            }	
                                        }
                                    } else if (TagElt[Index1]->Generic().GlobalId == KaxTagMultiCommercial::ClassInfos.GlobalId) {
                                        printf("    MultiCommercial:\n");
                                        KaxTagMultiCommercial & Commercials = *static_cast<KaxTagMultiCommercial *>(TagElt[Index1]);
                                        unsigned int Index2;
                                        for (Index2 = 0; Index2<Commercials.ListSize() ;Index2++) {
                                            if (Commercials[Index2]->Generic().GlobalId == KaxTagCommercial::ClassInfos.GlobalId) {
                                                printf("     Commercial:\n");
                                                KaxTagCommercial & Commercial = *static_cast<KaxTagCommercial *>(Commercials[Index2]);
                                                unsigned int Index3;
                                                for (Index3 = 0; Index3<Commercial.ListSize() ;Index3++) {
                                                    if (Commercial[Index3]->Generic().GlobalId == KaxTagMultiCommercialType::ClassInfos.GlobalId) {
                                                        printf("      Type:\n");
                                                    } else if (Commercial[Index3]->Generic().GlobalId == KaxTagMultiPrice::ClassInfos.GlobalId) {
                                                        printf("      Prices:\n");
                                                        KaxTagMultiPrice & Prices = *static_cast<KaxTagMultiPrice *>(Commercial[Index3]);
                                                        unsigned int Index4;
                                                        for (Index4 = 0; Index4<Prices.ListSize(); Index4++) {
                                                            if (Prices[Index4]->Generic().GlobalId == KaxTagMultiPriceCurrency::ClassInfos.GlobalId) {
                                                                printf("       Currency:\n");
                                                            } else if (Prices[Index4]->Generic().GlobalId == KaxTagMultiPriceAmount::ClassInfos.GlobalId) {
                                                                printf("       Amount:\n");
                                                            }	
                                                        }
                                                    }	
                                                }
                                            }	
                                        }
                                    } else if (TagElt[Index1]->Generic().GlobalId == KaxTagMultiDate::ClassInfos.GlobalId) {
                                        printf("    MultiDate:\n");
                                    } else if (TagElt[Index1]->Generic().GlobalId == KaxTagMultiComment::ClassInfos.GlobalId) {
                                        printf("    Comment:\n");
                                        KaxTagMultiComment & Comment = *static_cast<KaxTagMultiComment *>(TagElt[Index1]);
                                        unsigned int Index2;
                                        for (Index2 = 0; Index2<Comment.ListSize() ;Index2++) {
                                            if (Comment[Index2]->Generic().GlobalId == KaxTagMultiCommentName::ClassInfos.GlobalId) {
                                                KaxTagMultiCommentName & CommentName = *static_cast<KaxTagMultiCommentName *>(Comment[Index2]);
                                                printf("     Comment Name \"%s\"\n", std::string(CommentName).c_str());
                                            }	
                                        }
#endif
                                    }
                                }
                            }
                        }
                        if (AllTags->HasChecksum()) {
                            if (AllTags->VerifyChecksum()) {
                                printf(" ++ CheckSum verification succeeded ++\n");
                            } else {
                                printf(" ++ CheckSum verification FAILED !!! ++\n");
                            }
                        }
                    }
                    
                    if (UpperElementLevel > 0) {
                        UpperElementLevel--;
                        delete ElementLevel1;
                        ElementLevel1 = ElementLevel2;
                        if (UpperElementLevel > 0)
                            break;
                    } else {
                        ElementLevel1->SkipData(aStream, ElementLevel1->Generic().Context);
                        delete ElementLevel1;
                        
                        ElementLevel1 = aStream.FindNextElement(ElementLevel0->Generic().Context, UpperElementLevel, 0xFFFFFFFFL, bAllowDummy);
                    }
                }
            }
        }
        fclose(video_file);
        fclose(audio_file);
    }
    catch (exception & Ex)
    {
		cout << Ex.what() << endl;
		return -1;
    }
    
    return 0;
}
